# Operación Alquimia - Protocolo Savitar

Solución backend en **Java 17** y **Spring Boot 3.2.5** diseñada aplicando **Domain-Driven Design (DDD)** y **Arquitectura Hexagonal (Puertos y Adaptadores)** para reconstruir mensajes interceptados y localizar el laboratorio de Alchemy mediante trilateración.

## Ejecución
1. Abrir la carpeta descomprimida en VS Code, IntelliJ IDEA o Eclipse.
2. Ejecutar pruebas: `mvn test`
3. Iniciar servidor: `mvn spring-boot:run`
