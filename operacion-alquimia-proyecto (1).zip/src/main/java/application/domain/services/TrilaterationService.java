package application.domain.services;

import application.domain.exceptions.InsufficientDataException;
import application.domain.exceptions.InvalidSignalDataException;
import application.domain.models.SurveillanceSignal;
import application.domain.valueobjects.Coordinates;
import application.domain.valueobjects.DeviceType;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class TrilaterationService {

    private static final double EPSILON = 1e-6;
    private static final double DISTANCE_TOLERANCE = 0.5;

    public Coordinates calculateLocation(List<SurveillanceSignal> signals) {
        if (signals == null || signals.size() < 3) {
            throw new InsufficientDataException("Se requieren las senales de los 3 dispositivos de vigilancia para calcular la ubicacion.");
        }

        Map<DeviceType, SurveillanceSignal> signalMap = new EnumMap<>(DeviceType.class);
        for (SurveillanceSignal signal : signals) {
            signalMap.put(signal.getDeviceType(), signal);
        }

        if (signalMap.size() < 3) {
            throw new InsufficientDataException("Faltan dispositivos distintos; se requieren STAR Labs, CCPD y S.T.A.R. Satellite.");
        }

        SurveillanceSignal s1 = signalMap.get(DeviceType.STAR_LABS);
        SurveillanceSignal s2 = signalMap.get(DeviceType.CCPD);
        SurveillanceSignal s3 = signalMap.get(DeviceType.STAR_SATELLITE);

        Coordinates p1 = s1.getDeviceType().getCoordinates();
        Coordinates p2 = s2.getDeviceType().getCoordinates();
        Coordinates p3 = s3.getDeviceType().getCoordinates();

        double r1 = s1.getDistance();
        double r2 = s2.getDistance();
        double r3 = s3.getDistance();

        double a = 2 * (p2.getX() - p1.getX());
        double b = 2 * (p2.getY() - p1.getY());
        double c = r1 * r1 - r2 * r2 - p1.getX() * p1.getX() + p2.getX() * p2.getX() - p1.getY() * p1.getY() + p2.getY() * p2.getY();

        double d = 2 * (p3.getX() - p2.getX());
        double e = 2 * (p3.getY() - p2.getY());
        double f = r2 * r2 - r3 * r3 - p2.getX() * p2.getX() + p3.getX() * p3.getX() - p2.getY() * p2.getY() + p3.getY() * p3.getY();

        double determinant = a * e - b * d;
        if (Math.abs(determinant) < EPSILON) {
            throw new InvalidSignalDataException("No es posible determinar una ubicacion unica (dispositivos colineales).");
        }

        double x = (c * e - f * b) / determinant;
        double y = (a * f - d * c) / determinant;

        double calcR1 = Math.hypot(x - p1.getX(), y - p1.getY());
        double calcR2 = Math.hypot(x - p2.getX(), y - p2.getY());
        double calcR3 = Math.hypot(x - p3.getX(), y - p3.getY());

        if (Math.abs(calcR1 - r1) > DISTANCE_TOLERANCE ||
            Math.abs(calcR2 - r2) > DISTANCE_TOLERANCE ||
            Math.abs(calcR3 - r3) > DISTANCE_TOLERANCE) {
            throw new InvalidSignalDataException("Las distancias proporcionadas no intersectan en un punto comun valido.");
        }

        double roundedX = Math.round(x * 100.0) / 100.0;
        double roundedY = Math.round(y * 100.0) / 100.0;

        return new Coordinates(roundedX, roundedY);
    }
}
