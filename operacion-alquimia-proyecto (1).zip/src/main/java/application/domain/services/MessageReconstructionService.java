package application.domain.services;

import application.domain.exceptions.InsufficientDataException;
import application.domain.exceptions.InvalidSignalDataException;
import application.domain.models.SurveillanceSignal;

import java.util.ArrayList;
import java.util.List;

public class MessageReconstructionService {

    public String reconstructMessage(List<SurveillanceSignal> signals) {
        if (signals == null || signals.size() < 3) {
            throw new InsufficientDataException("No hay informacion suficiente de los dispositivos para reconstruir el mensaje.");
        }

        int minLen = signals.stream()
                .mapToInt(s -> s.getMessage().size())
                .min()
                .orElse(0);

        if (minLen == 0) {
            throw new InvalidSignalDataException("Uno de los fragmentos de mensaje esta vacio.");
        }

        List<List<String>> alignedMessages = new ArrayList<>();
        for (SurveillanceSignal signal : signals) {
            List<String> msg = signal.getMessage();
            int offset = msg.size() - minLen;
            alignedMessages.add(msg.subList(offset, msg.size()));
        }

        String[] reconstructed = new String[minLen];
        for (int i = 0; i < minLen; i++) {
            String resolvedWord = null;
            for (List<String> fragment : alignedMessages) {
                String word = fragment.get(i).trim();
                if (!word.isEmpty()) {
                    if (resolvedWord != null && !resolvedWord.equals(word)) {
                        throw new InvalidSignalDataException(
                                "Conflicto en la reconstruccion del mensaje en la posicion " + (i + 1) +
                                ": '" + resolvedWord + "' vs '" + word + "'."
                        );
                    }
                    resolvedWord = word;
                }
            }
            if (resolvedWord == null) {
                throw new InsufficientDataException("No se pudo determinar la palabra en la posicion " + (i + 1) + " del mensaje.");
            }
            reconstructed[i] = resolvedWord;
        }

        return String.join(" ", reconstructed);
    }
}
