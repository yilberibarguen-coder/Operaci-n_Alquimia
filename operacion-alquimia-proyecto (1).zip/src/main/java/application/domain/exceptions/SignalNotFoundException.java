package application.domain.exceptions;

public class SignalNotFoundException extends DomainException {
    public SignalNotFoundException(String message) {
        super(message);
    }
}
