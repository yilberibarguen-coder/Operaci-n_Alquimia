package application.domain.exceptions;

public class InvalidSignalDataException extends DomainException {
    public InvalidSignalDataException(String message) {
        super(message);
    }
}
