package application.domain.ports.in;

import application.domain.models.AlchemyAnalysisResult;
import application.domain.models.SurveillanceSignal;

import java.util.List;

public interface ManageDeviceSignalPort {
    SurveillanceSignal registerSignal(String deviceName, Double distance, List<String> message);
    AlchemyAnalysisResult analyzeStoredSignals();
    List<SurveillanceSignal> getAllStoredSignals();
    SurveillanceSignal replaceSignal(String deviceName, Double distance, List<String> message);
    SurveillanceSignal partialUpdateSignal(String deviceName, Double distance, List<String> message);
    void deleteSignal(String deviceName);
}
