package application.domain.ports.in;

import application.domain.models.AlchemyAnalysisResult;
import application.domain.models.SurveillanceSignal;

import java.util.List;

public interface ProcessCompleteSignalsPort {
    AlchemyAnalysisResult processAll(List<SurveillanceSignal> signals);
}
