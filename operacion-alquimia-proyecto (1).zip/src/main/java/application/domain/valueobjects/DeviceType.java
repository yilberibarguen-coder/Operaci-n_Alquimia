package application.domain.valueobjects;

import application.domain.exceptions.UnknownDeviceException;

import java.util.Arrays;

public enum DeviceType {
    STAR_LABS("starlabs", "STAR Labs", new Coordinates(-500.0, -200.0)),
    CCPD("ccpd", "CCPD", new Coordinates(100.0, -100.0)),
    STAR_SATELLITE("starsatellite", "S.T.A.R. Satellite", new Coordinates(500.0, 100.0));

    private final String code;
    private final String displayName;
    private final Coordinates coordinates;

    DeviceType(String code, String displayName, Coordinates coordinates) {
        this.code = code;
        this.displayName = displayName;
        this.coordinates = coordinates;
    }

    public String getCode() {
        return code;
    }

    public String getDisplayName() {
        return displayName;
    }

    public Coordinates getCoordinates() {
        return coordinates;
    }

    public static DeviceType fromName(String rawName) {
        if (rawName == null || rawName.isBlank()) {
            throw new UnknownDeviceException("El nombre del dispositivo no puede estar vacio.");
        }
        String normalized = rawName.toLowerCase().replaceAll("[^a-z0-9]", "");
        return Arrays.stream(values())
                .filter(d -> d.code.equals(normalized))
                .findFirst()
                .orElseThrow(() -> new UnknownDeviceException("Dispositivo de vigilancia desconocido: " + rawName));
    }
}
