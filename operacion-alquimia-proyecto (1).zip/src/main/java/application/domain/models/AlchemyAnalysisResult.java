package application.domain.models;

import application.domain.valueobjects.Coordinates;

public class AlchemyAnalysisResult {
    private final Coordinates position;
    private final String message;

    public AlchemyAnalysisResult(Coordinates position, String message) {
        this.position = position;
        this.message = message;
    }

    public Coordinates getPosition() {
        return position;
    }

    public String getMessage() {
        return message;
    }
}
