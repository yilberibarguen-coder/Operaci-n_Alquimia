package application.domain.models;

import application.domain.exceptions.InvalidSignalDataException;
import application.domain.valueobjects.DeviceType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SurveillanceSignal {
    private final DeviceType deviceType;
    private final double distance;
    private final List<String> message;

    public SurveillanceSignal(DeviceType deviceType, Double distance, List<String> message) {
        if (deviceType == null) {
            throw new InvalidSignalDataException("El tipo de dispositivo es obligatorio.");
        }
        if (distance == null || Double.isNaN(distance) || Double.isInfinite(distance) || distance < 0) {
            throw new InvalidSignalDataException("La distancia debe ser un numero mayor o igual a cero.");
        }
        if (message == null || message.isEmpty()) {
            throw new InvalidSignalDataException("El fragmento del mensaje no puede ser nulo ni vacio.");
        }
        for (String word : message) {
            if (word == null) {
                throw new InvalidSignalDataException("El mensaje no puede contener elementos nulos (use cadena vacia "").");
            }
        }
        this.deviceType = deviceType;
        this.distance = distance;
        this.message = Collections.unmodifiableList(new ArrayList<>(message));
    }

    public DeviceType getDeviceType() {
        return deviceType;
    }

    public double getDistance() {
        return distance;
    }

    public List<String> getMessage() {
        return message;
    }
}
