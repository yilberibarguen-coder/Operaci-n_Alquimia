package application.adapters.persistence;

import application.domain.models.SurveillanceSignal;
import application.domain.ports.out.SignalRepositoryPort;
import application.domain.valueobjects.DeviceType;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemorySignalRepositoryAdapter implements SignalRepositoryPort {

    private final Map<DeviceType, SurveillanceSignal> storage = new ConcurrentHashMap<>();

    @Override
    public SurveillanceSignal save(SurveillanceSignal signal) {
        storage.put(signal.getDeviceType(), signal);
        return signal;
    }

    @Override
    public Optional<SurveillanceSignal> findByDeviceType(DeviceType deviceType) {
        return Optional.ofNullable(storage.get(deviceType));
    }

    @Override
    public List<SurveillanceSignal> findAll() {
        return new ArrayList<>(storage.values());
    }

    @Override
    public boolean existsByDeviceType(DeviceType deviceType) {
        return storage.containsKey(deviceType);
    }

    @Override
    public void deleteByDeviceType(DeviceType deviceType) {
        storage.remove(deviceType);
    }
}
