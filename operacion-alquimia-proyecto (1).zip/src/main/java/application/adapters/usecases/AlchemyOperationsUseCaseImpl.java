package application.adapters.usecases;

import application.domain.exceptions.InsufficientDataException;
import application.domain.exceptions.InvalidSignalDataException;
import application.domain.exceptions.SignalNotFoundException;
import application.domain.models.AlchemyAnalysisResult;
import application.domain.models.SurveillanceSignal;
import application.domain.ports.in.ManageDeviceSignalPort;
import application.domain.ports.in.ProcessCompleteSignalsPort;
import application.domain.ports.out.SignalRepositoryPort;
import application.domain.services.MessageReconstructionService;
import application.domain.services.TrilaterationService;
import application.domain.valueobjects.Coordinates;
import application.domain.valueobjects.DeviceType;

import java.util.EnumSet;
import java.util.List;
import java.util.Set;

public class AlchemyOperationsUseCaseImpl implements ProcessCompleteSignalsPort, ManageDeviceSignalPort {

    private final SignalRepositoryPort signalRepositoryPort;
    private final TrilaterationService trilaterationService;
    private final MessageReconstructionService messageReconstructionService;

    public AlchemyOperationsUseCaseImpl(
            SignalRepositoryPort signalRepositoryPort,
            TrilaterationService trilaterationService,
            MessageReconstructionService messageReconstructionService) {
        this.signalRepositoryPort = signalRepositoryPort;
        this.trilaterationService = trilaterationService;
        this.messageReconstructionService = messageReconstructionService;
    }

    @Override
    public AlchemyAnalysisResult processAll(List<SurveillanceSignal> signals) {
        if (signals == null || signals.size() != 3) {
            throw new InvalidSignalDataException("Debe proporcionar exactamente la informacion de los 3 dispositivos de vigilancia.");
        }

        Set<DeviceType> uniqueDevices = EnumSet.noneOf(DeviceType.class);
        for (SurveillanceSignal signal : signals) {
            if (!uniqueDevices.add(signal.getDeviceType())) {
                throw new InvalidSignalDataException("Dispositivo duplicado en la solicitud: " + signal.getDeviceType().getDisplayName());
            }
        }

        Coordinates location = trilaterationService.calculateLocation(signals);
        String message = messageReconstructionService.reconstructMessage(signals);
        return new AlchemyAnalysisResult(location, message);
    }

    @Override
    public SurveillanceSignal registerSignal(String deviceName, Double distance, List<String> message) {
        DeviceType deviceType = DeviceType.fromName(deviceName);
        SurveillanceSignal signal = new SurveillanceSignal(deviceType, distance, message);
        return signalRepositoryPort.save(signal);
    }

    @Override
    public AlchemyAnalysisResult analyzeStoredSignals() {
        List<SurveillanceSignal> stored = signalRepositoryPort.findAll();
        if (stored.size() < 3) {
            throw new InsufficientDataException(
                    "No existen datos suficientes para calcular la ubicacion y reconstruir el mensaje. Dispositivos registrados: "
                            + stored.size() + " de 3."
            );
        }
        Coordinates location = trilaterationService.calculateLocation(stored);
        String message = messageReconstructionService.reconstructMessage(stored);
        return new AlchemyAnalysisResult(location, message);
    }

    @Override
    public List<SurveillanceSignal> getAllStoredSignals() {
        return signalRepositoryPort.findAll();
    }

    @Override
    public SurveillanceSignal replaceSignal(String deviceName, Double distance, List<String> message) {
        DeviceType deviceType = DeviceType.fromName(deviceName);
        if (!signalRepositoryPort.existsByDeviceType(deviceType)) {
            throw new SignalNotFoundException("No existe informacion previamente registrada para el dispositivo: " + deviceType.getDisplayName());
        }
        SurveillanceSignal replacement = new SurveillanceSignal(deviceType, distance, message);
        return signalRepositoryPort.save(replacement);
    }

    @Override
    public SurveillanceSignal partialUpdateSignal(String deviceName, Double distance, List<String> message) {
        DeviceType deviceType = DeviceType.fromName(deviceName);
        SurveillanceSignal existing = signalRepositoryPort.findByDeviceType(deviceType)
                .orElseThrow(() -> new SignalNotFoundException(
                        "No existe informacion previamente registrada para el dispositivo: " + deviceType.getDisplayName()));

        if (distance == null && message == null) {
            throw new InvalidSignalDataException("Debe proporcionar al menos la distancia o el fragmento del mensaje para actualizar.");
        }

        double updatedDistance = (distance != null) ? distance : existing.getDistance();
        List<String> updatedMessage = (message != null) ? message : existing.getMessage();

        SurveillanceSignal updated = new SurveillanceSignal(deviceType, updatedDistance, updatedMessage);
        return signalRepositoryPort.save(updated);
    }

    @Override
    public void deleteSignal(String deviceName) {
        DeviceType deviceType = DeviceType.fromName(deviceName);
        if (!signalRepositoryPort.existsByDeviceType(deviceType)) {
            throw new SignalNotFoundException("No existe informacion almacenada para el dispositivo: " + deviceType.getDisplayName());
        }
        signalRepositoryPort.deleteByDeviceType(deviceType);
    }
}
