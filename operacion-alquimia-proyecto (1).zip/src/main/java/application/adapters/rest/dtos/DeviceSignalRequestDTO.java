package application.adapters.rest.dtos;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.util.List;

public class DeviceSignalRequestDTO {

    @NotBlank(message = "El nombre del dispositivo es obligatorio")
    private String name;

    @NotNull(message = "La distancia es obligatoria")
    @PositiveOrZero(message = "La distancia debe ser mayor o igual a cero")
    private Double distance;

    @NotEmpty(message = "El mensaje no puede estar vacio")
    private List<String> message;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public List<String> getMessage() {
        return message;
    }

    public void setMessage(List<String> message) {
        this.message = message;
    }
}
