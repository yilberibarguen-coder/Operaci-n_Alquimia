package application.adapters.rest.dtos;

import java.util.List;

public class StoredDeviceSignalResponseDTO {
    private String device;
    private double distance;
    private List<String> message;

    public StoredDeviceSignalResponseDTO(String device, double distance, List<String> message) {
        this.device = device;
        this.distance = distance;
        this.message = message;
    }

    public String getDevice() {
        return device;
    }

    public double getDistance() {
        return distance;
    }

    public List<String> getMessage() {
        return message;
    }
}
