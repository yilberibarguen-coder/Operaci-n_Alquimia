package application.adapters.rest.dtos;

import jakarta.validation.constraints.PositiveOrZero;

import java.util.List;

public class PartialDevicePayloadDTO {

    @PositiveOrZero(message = "La distancia debe ser mayor o igual a cero")
    private Double distance;

    private List<String> message;

    public Double getDistance() {
        return distance;
    }

    public void setDistance(Double distance) {
        this.distance = distance;
    }

    public List<String> getMessage() {
        return message;
    }

    public void setMessage(List<String> message) {
        this.message = message;
    }
}
