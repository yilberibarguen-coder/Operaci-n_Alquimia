package application.adapters.rest.dtos;

public class AlchemyResponseDTO {
    private PositionResponseDTO position;
    private String message;

    public AlchemyResponseDTO(PositionResponseDTO position, String message) {
        this.position = position;
        this.message = message;
    }

    public PositionResponseDTO getPosition() {
        return position;
    }

    public String getMessage() {
        return message;
    }
}
