package application.adapters.rest.dtos;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;

import java.util.List;

public class CompleteSignalsRequestDTO {

    @NotEmpty(message = "La lista de dispositivos es obligatoria")
    @Size(min = 3, max = 3, message = "Debe enviar exactamente 3 dispositivos")
    @Valid
    private List<DeviceSignalRequestDTO> devices;

    public List<DeviceSignalRequestDTO> getDevices() {
        return devices;
    }

    public void setDevices(List<DeviceSignalRequestDTO> devices) {
        this.devices = devices;
    }
}
