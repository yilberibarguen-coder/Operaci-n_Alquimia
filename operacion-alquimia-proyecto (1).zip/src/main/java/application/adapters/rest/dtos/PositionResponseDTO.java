package application.adapters.rest.dtos;

public class PositionResponseDTO {
    private double x;
    private double y;

    public PositionResponseDTO(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
