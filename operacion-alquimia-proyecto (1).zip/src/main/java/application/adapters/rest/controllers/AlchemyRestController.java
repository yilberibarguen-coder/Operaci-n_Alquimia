package application.adapters.rest.controllers;

import application.adapters.rest.dtos.*;
import application.domain.models.AlchemyAnalysisResult;
import application.domain.models.SurveillanceSignal;
import application.domain.ports.in.ManageDeviceSignalPort;
import application.domain.ports.in.ProcessCompleteSignalsPort;
import application.domain.valueobjects.DeviceType;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
public class AlchemyRestController {

    private final ProcessCompleteSignalsPort processCompleteSignalsPort;
    private final ManageDeviceSignalPort manageDeviceSignalPort;

    public AlchemyRestController(
            ProcessCompleteSignalsPort processCompleteSignalsPort,
            ManageDeviceSignalPort manageDeviceSignalPort) {
        this.processCompleteSignalsPort = processCompleteSignalsPort;
        this.manageDeviceSignalPort = manageDeviceSignalPort;
    }

    @PostMapping("/alchemy")
    public ResponseEntity<AlchemyResponseDTO> processCompleteSignals(
            @Valid @RequestBody CompleteSignalsRequestDTO request) {

        List<SurveillanceSignal> domainSignals = request.getDevices().stream()
                .map(dto -> new SurveillanceSignal(
                        DeviceType.fromName(dto.getName()),
                        dto.getDistance(),
                        dto.getMessage()))
                .toList();

        AlchemyAnalysisResult result = processCompleteSignalsPort.processAll(domainSignals);
        return ResponseEntity.ok(toAlchemyResponse(result));
    }

    @PostMapping("/alchemy-split/{deviceName}")
    public ResponseEntity<StoredDeviceSignalResponseDTO> registerIndividualSignal(
            @PathVariable String deviceName,
            @Valid @RequestBody SingleDevicePayloadDTO request) {

        SurveillanceSignal saved = manageDeviceSignalPort.registerSignal(
                deviceName,
                request.getDistance(),
                request.getMessage());

        return ResponseEntity.status(HttpStatus.CREATED).body(toStoredResponse(saved));
    }

    @GetMapping("/alchemy-split")
    public ResponseEntity<AlchemyResponseDTO> getAccumulatedAnalysis() {
        AlchemyAnalysisResult result = manageDeviceSignalPort.analyzeStoredSignals();
        return ResponseEntity.ok(toAlchemyResponse(result));
    }

    @GetMapping("/alchemy-split/devices")
    public ResponseEntity<List<StoredDeviceSignalResponseDTO>> listStoredSignals() {
        List<StoredDeviceSignalResponseDTO> list = manageDeviceSignalPort.getAllStoredSignals().stream()
                .map(this::toStoredResponse)
                .toList();
        return ResponseEntity.ok(list);
    }

    @PutMapping("/alchemy-split/{deviceName}")
    public ResponseEntity<StoredDeviceSignalResponseDTO> replaceDeviceSignal(
            @PathVariable String deviceName,
            @Valid @RequestBody SingleDevicePayloadDTO request) {

        SurveillanceSignal updated = manageDeviceSignalPort.replaceSignal(
                deviceName,
                request.getDistance(),
                request.getMessage());

        return ResponseEntity.ok(toStoredResponse(updated));
    }

    @PatchMapping("/alchemy-split/{deviceName}")
    public ResponseEntity<StoredDeviceSignalResponseDTO> partialUpdateDeviceSignal(
            @PathVariable String deviceName,
            @Valid @RequestBody PartialDevicePayloadDTO request) {

        SurveillanceSignal updated = manageDeviceSignalPort.partialUpdateSignal(
                deviceName,
                request.getDistance(),
                request.getMessage());

        return ResponseEntity.ok(toStoredResponse(updated));
    }

    @DeleteMapping("/alchemy-split/{deviceName}")
    public ResponseEntity<Void> deleteDeviceSignal(@PathVariable String deviceName) {
        manageDeviceSignalPort.deleteSignal(deviceName);
        return ResponseEntity.noContent().build();
    }

    private AlchemyResponseDTO toAlchemyResponse(AlchemyAnalysisResult result) {
        return new AlchemyResponseDTO(
                new PositionResponseDTO(result.getPosition().getX(), result.getPosition().getY()),
                result.getMessage()
        );
    }

    private StoredDeviceSignalResponseDTO toStoredResponse(SurveillanceSignal signal) {
        return new StoredDeviceSignalResponseDTO(
                signal.getDeviceType().getDisplayName(),
                signal.getDistance(),
                signal.getMessage()
        );
    }
}
