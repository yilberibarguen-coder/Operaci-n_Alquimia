package application.infrastructure.config;

import application.adapters.usecases.AlchemyOperationsUseCaseImpl;
import application.domain.ports.out.SignalRepositoryPort;
import application.domain.services.MessageReconstructionService;
import application.domain.services.TrilaterationService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DomainBeanConfiguration {

    @Bean
    public TrilaterationService trilaterationService() {
        return new TrilaterationService();
    }

    @Bean
    public MessageReconstructionService messageReconstructionService() {
        return new MessageReconstructionService();
    }

    @Bean
    public AlchemyOperationsUseCaseImpl alchemyOperationsUseCase(
            SignalRepositoryPort signalRepositoryPort,
            TrilaterationService trilaterationService,
            MessageReconstructionService messageReconstructionService) {
        return new AlchemyOperationsUseCaseImpl(
                signalRepositoryPort,
                trilaterationService,
                messageReconstructionService
        );
    }
}
