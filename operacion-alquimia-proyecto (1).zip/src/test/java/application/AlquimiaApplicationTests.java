package application;

import application.domain.models.SurveillanceSignal;
import application.domain.services.MessageReconstructionService;
import application.domain.services.TrilaterationService;
import application.domain.valueobjects.Coordinates;
import application.domain.valueobjects.DeviceType;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class AlquimiaApplicationTests {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void testDomainTrilaterationAndMessageReconstruction() {
        double d1 = Math.hypot(-100 - (-500), 75.5 - (-200));
        double d2 = Math.hypot(-100 - 100, 75.5 - (-100));
        double d3 = Math.hypot(-100 - 500, 75.5 - 100);

        List<SurveillanceSignal> signals = List.of(
                new SurveillanceSignal(DeviceType.STAR_LABS, d1, List.of("este", "", "", "mensaje", "")),
                new SurveillanceSignal(DeviceType.CCPD, d2, List.of("", "es", "", "", "secreto")),
                new SurveillanceSignal(DeviceType.STAR_SATELLITE, d3, List.of("este", "", "un", "", ""))
        );

        TrilaterationService trilaterationService = new TrilaterationService();
        MessageReconstructionService messageService = new MessageReconstructionService();

        Coordinates coords = trilaterationService.calculateLocation(signals);
        String msg = messageService.reconstructMessage(signals);

        assertEquals(-100.0, coords.getX(), 0.01);
        assertEquals(75.5, coords.getY(), 0.01);
        assertEquals("este es un mensaje secreto", msg);
    }

    @Test
    void testCompleteAndSplitEndpointsFlow() throws Exception {
        double d1 = Math.hypot(0 - (-500), 0 - (-200));
        double d2 = Math.hypot(0 - 100, 0 - (-100));
        double d3 = Math.hypot(0 - 500, 0 - 100);

        String completePayload = String.format("""
                {
                  "devices": [
                    {"name": "starlabs", "distance": %s, "message": ["savitar", "", "regresa", ""]},
                    {"name": "ccpd", "distance": %s, "message": ["", "ya", "", "pronto"]},
                    {"name": "starsatellite", "distance": %s, "message": ["savitar", "", "", "pronto"]}
                  ]
                }
                """, d1, d2, d3);

        mockMvc.perform(post("/api/v1/alchemy")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(completePayload))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.position.x").value(0.0))
                .andExpect(jsonPath("$.position.y").value(0.0))
                .andExpect(jsonPath("$.message").value("savitar ya regresa pronto"));

        mockMvc.perform(get("/api/v1/alchemy-split"))
                .andExpect(status().isBadRequest());

        mockMvc.perform(post("/api/v1/alchemy-split/starlabs")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{"distance": %s, "message": ["savitar", "", "regresa", ""]}", d1)))
                .andExpect(status().isCreated());

        mockMvc.perform(post("/api/v1/alchemy-split/ccpd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{"distance": %s, "message": ["", "ya", "", "pronto"]}", d2)))
                .andExpect(status().isCreated());

        mockMvc.perform(post("/api/v1/alchemy-split/starsatellite")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(String.format("{"distance": %s, "message": ["savitar", "", "", "pronto"]}", d3)))
                .andExpect(status().isCreated());

        mockMvc.perform(get("/api/v1/alchemy-split"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("savitar ya regresa pronto"));

        mockMvc.perform(patch("/api/v1/alchemy-split/ccpd")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{"message": ["", "no", "", "pronto"]}"))
                .andExpect(status().isOk());

        mockMvc.perform(get("/api/v1/alchemy-split"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("savitar no regresa pronto"));

        mockMvc.perform(delete("/api/v1/alchemy-split/ccpd"))
                .andExpect(status().isNoContent());

        mockMvc.perform(get("/api/v1/alchemy-split"))
                .andExpect(status().isBadRequest());
    }
}
